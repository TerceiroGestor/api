// coreui/form-engine/types.ts

/* ----------------------------------------
 * Modo do formulário
 * ---------------------------------------- */
export type FormMode = "edit" | "view";

type BaseField<T> = {
  name: keyof T & string;
  label: string;
};
export type TextField<T> = BaseField<T> & {
  type: "text" | "number" | "money";
};
export type BooleanField<T> = BaseField<T> & {
  type: "boolean" | "check";
};
export type SelectField<T> = BaseField<T> & {
  type: "select" | "multiselect";
  options: { label: string; value: any }[];
};
export type RichTextField<T> = BaseField<T> & {
  type: "richtext";
};

export type FormField<T> = TextField<T> | BooleanField<T> | SelectField<T> | RichTextField<T>;

/* ----------------------------------------
 * Step (NUNCA sem fields)
 * ---------------------------------------- */
export type FormStep<T> = {
  id: string;
  label?: string;
  fields: FormField<T>[]; // ✅ NÃO opcional
};

/* ----------------------------------------
 * Props do FormEngine
 * ---------------------------------------- */
export type FormEngineProps<T> =
  | {
      fields: FormField<T>[]; // modo simples
      steps?: never;
      onSubmit: (data: T) => void;
    }
  | {
      steps: FormStep<T>[]; // modo avançado
      fields?: never;
      onSubmit: (data: T) => void;
    };
