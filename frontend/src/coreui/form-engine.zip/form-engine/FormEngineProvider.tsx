type FormEngineProviderProps = {
  children: React.ReactNode;
};

export function FormEngineProvider({
  children,
}: FormEngineProviderProps) {
  return <>{children}</>;
}
