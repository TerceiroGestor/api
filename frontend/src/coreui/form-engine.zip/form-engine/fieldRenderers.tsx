import React from "react";
import { FormField, FormMode } from "./types";
import { InputDefault, InputNumber, InputMoney } from "@coreui/ui/inputs";
import { Toggle, Check } from "@/coreui/ui/check";
import { Select, MultiSelect } from "@/coreui/ui/select";
import { RichText } from "@/coreui/ui/richtext/RichTextField";
import { TextField, BooleanField, SelectField, RichTextField } from "./types";
import { JSX } from "react";

export type FieldRenderer<T = any> = (props: {
  field: FormField<T>;
  value: any;
  mode: FormMode;
  onChange: (value: any) => void;
}) => JSX.Element;

export const fieldRenderers: Record<FormField<any>["type"], FieldRenderer> = {
  text: ({ field, value, mode, onChange }) => (
    <input
      value={value ?? ""}
      disabled={mode === "view"}
      onChange={(e) => onChange(e.target.value)}
      className="w-full border px-3 py-2"
    />
  ),

  number: ({ field, value, mode, onChange }) => (
    <input
      type="number"
      value={value ?? ""}
      disabled={mode === "view"}
      onChange={(e) => onChange(Number(e.target.value))}
      className="w-full border px-3 py-2"
    />
  ),

  boolean: ({ value, mode, onChange }) => (
    <input
      type="checkbox"
      checked={!!value}
      disabled={mode === "view"}
      onChange={(e) => onChange(e.target.checked)}
    />
  ),

  select: ({ field, value, mode, onChange }) => (
    <select
      value={value ?? ""}
      disabled={mode === "view"}
      onChange={(e) => onChange(e.target.value)}
      className="w-full border px-3 py-2"
    >
      {field.options?.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
  ),

  richtext: ({ value, mode, onChange }) => (
    <div>
      {/* seu RichTextField real entra aqui */}
      <textarea
        value={value ?? ""}
        disabled={mode === "view"}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border px-3 py-2"
      />
    </div>
  ),
};
