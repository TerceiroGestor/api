"use client";

import { useState } from "react";
import { FormEngineProps, FormStep, FormField, FormMode } from "./types";
import { fieldRenderers } from "./fieldRenderers";

/* -------------------------------------------------------
 * Helper para renderização tipada de campos
 * ----------------------------------------------------- */
function renderField<T>(
  field: FormField<T>,
  value: any,
  mode: FormMode,
  onChange: (value: any) => void
) {
  const Renderer = fieldRenderers[field.type];

  // TS não consegue inferir union por index access,
  // então fazemos narrowing manual controlado
  return Renderer({
    field: field as any,
    value,
    mode,
    onChange,
  });
}

export function FormEngine<T>(props: FormEngineProps<T>) {
  const mode: FormMode = "edit";

  /* -------------------------------------------------------
   * Normalização: fields → steps
   * ----------------------------------------------------- */
  let steps: FormStep<T>[];

  if ("fields" in props) {
    steps = [
      {
        id: "default",
        label: "",
        fields: props.fields, // garantido pelo type
      },
    ];
  } else {
    steps = props.steps;
  }

  /* -------------------------------------------------------
   * Estado do formulário
   * ----------------------------------------------------- */
  const [data, setData] = useState<Partial<T>>({});

  function setValue(name: keyof T & string, value: any) {
    setData((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    props.onSubmit(data as T);
  }

  /* -------------------------------------------------------
   * Render
   * ----------------------------------------------------- */
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {steps.map((step) => (
        <div key={step.id} className="space-y-4">
          {step.label && <h3 className="text-lg font-semibold">{step.label}</h3>}

          {step.fields.map((field) => (
            <div key={field.name} className="space-y-1">
              {field.label && <label className="block text-sm font-medium">{field.label}</label>}

              {renderField(field, data[field.name], mode, (value) => setValue(field.name, value))}
            </div>
          ))}
        </div>
      ))}

      <div className="pt-4">
        <button
          type="submit"
          className="bg-brand-500 hover:bg-brand-600 rounded-md px-4 py-2 text-white"
        >
          Salvar
        </button>
      </div>
    </form>
  );
}
