import { ReactNode } from "react";
import { FormField, FormMode } from "./types";

export type FieldRendererProps = {
  value: any;
  onChange: (value: any) => void;
  mode: FormMode;
  field: FormField<any>;
};

export type FieldRenderer = (props: FieldRendererProps) => ReactNode;
