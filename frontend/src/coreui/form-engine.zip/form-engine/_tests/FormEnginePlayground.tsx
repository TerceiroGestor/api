"use client";

import { FormEngine } from "../FormEngine";
import { FormField } from "../types";

type Data = {
  name: string;
  age: number;
  active: boolean;
};

export default function FormEnginePlayground() {
  const fields: FormField<Data>[] = [
    { name: "name", label: "Nome", type: "text", required: true },
    { name: "age", label: "Idade", type: "number" },
    { name: "active", label: "Ativo", type: "boolean" },
  ];

  function handleSubmit(data: Data) {
    console.log("SUBMIT:", data);
  }

  return (
    <div className="max-w-lg p-6">
      <FormEngine fields={fields} onSubmit={handleSubmit} />
    </div>
  );
}
