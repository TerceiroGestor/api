"use client";

import { useState } from "react";
import { fieldRenderers } from "../fieldRenderers";
import { FormField } from "../types";

export default function FieldRenderersPlayground() {
  const [data, setData] = useState<Record<string, any>>({
    name: "",
    age: 0,
    active: false,
    role: "",
    tags: [],
    description: "",
  });

  function render(field: FormField<any>) {
    const Renderer = fieldRenderers[field.type];

    return (
      <div key={field.name} className="mb-4">
        <label className="mb-1 block text-sm font-medium">{field.label}</label>

        {Renderer({
          field,
          value: data[field.name],
          mode: "edit",
          onChange: (value) => setData((prev) => ({ ...prev, [field.name]: value })),
        })}
      </div>
    );
  }

  const fields: FormField<any>[] = [
    { name: "name", label: "Nome", type: "text" },
    { name: "age", label: "Idade", type: "number" },
    { name: "money", label: "Renda", type: "money" },
    { name: "active", label: "Ativo", type: "boolean" },
    {
      name: "role",
      label: "Cargo",
      type: "select",
      options: [
        { label: "Admin", value: "admin" },
        { label: "User", value: "user" },
      ],
    },
    {
      name: "tags",
      label: "Tags",
      type: "multiselect",
      options: [
        { label: "A", value: "a" },
        { label: "B", value: "b" },
      ],
    },
    {
      name: "description",
      label: "Descrição",
      type: "richtext",
    },
  ];

  return (
    <div className="flex items-center justify-center">
      <div>
        <h1>Form Default</h1>
        <hr className="mb-5" />
        {fields.map(render)}
      </div>
    </div>
  );
}
