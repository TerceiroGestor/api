// useInputMask.ts
import { MaskHandler } from "@coreui/ui/mask/mask.types";

export function useInputMask(
  mask?: MaskHandler,
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void
) {
  if (!mask) return onChange;

  return (e: React.ChangeEvent<HTMLInputElement>) => {
    const native = e.nativeEvent as InputEvent | undefined;

    // clear ou delete → respeita
    if (!native || native.inputType?.startsWith("delete")) {
      onChange?.(e);
      return;
    }

    const formatted = mask.format(e.target.value);

    onChange?.({
      ...e,
      target: {
        ...e.target,
        value: formatted,
      },
    } as React.ChangeEvent<HTMLInputElement>);
  };
}
