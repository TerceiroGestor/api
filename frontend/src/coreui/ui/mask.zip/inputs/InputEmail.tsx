import { InputDefault } from "./InputDefault";
import { emailMask } from "../mask/email.mask";

type InputEmailProps = Omit<React.ComponentProps<typeof InputDefault>, "type" | "mask">;

export function InputEmail(props: InputEmailProps) {
  return <InputDefault {...props} type="email" mask={emailMask} />;
}
