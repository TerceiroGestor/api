import { useState } from "react";
import { InputBase } from "./InputBase";
import { useInputMask } from "./useInputMask";
import { MaskHandler } from "../mask/mask.types";

type InputDefaultProps = {
  mask?: MaskHandler;
  message?: string;
  variant?: "default" | "error" | "success";
} & React.ComponentProps<typeof InputBase>;

export function InputDefault({
  mask,
  value,
  message,
  variant,
  onChange,
  onBlur,
  ...props
}: InputDefaultProps) {
  const [touched, setTouched] = useState(false);
  const maskedOnChange = useInputMask(mask, onChange);

  function handleBlur(e: React.FocusEvent<HTMLInputElement>) {
    setTouched(true);
    onBlur?.(e);
  }

  const shouldValidate = mask?.validate && touched && mask.validateOn === "blur";

  const isInvalid = shouldValidate && !mask!.validate!(value || "");

  const computedVariant = variant ?? (isInvalid ? "error" : shouldValidate ? "success" : "default");

  const computedMessage = isInvalid ? message : undefined;

  return (
    <InputBase
      {...props}
      value={value}
      onChange={maskedOnChange}
      onBlur={handleBlur}
      variant={computedVariant}
      message={computedMessage}
    />
  );
}
