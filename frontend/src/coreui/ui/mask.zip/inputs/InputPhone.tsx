import { InputDefault } from "./InputDefault";
import { phoneMask } from "../mask";

type InputPhoneProps = Omit<React.ComponentProps<typeof InputDefault>, "type" | "mask">;

export function InputPhone(props: InputPhoneProps) {
  return <InputDefault {...props} type="tel" mask={phoneMask} inputMode="numeric" />;
}
