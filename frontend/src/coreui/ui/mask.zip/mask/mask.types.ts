// masks/mask.types.ts
export type MaskHandler = {
  /**
   * Recebe o valor cru digitado
   * Retorna o valor formatado
   */
  format: (raw: string) => string;

  /**
   * Diz se o valor final é válido
   * (opcional)
   */
  validate?: (value: string) => boolean;

  /**
   * Quando a validação deve acontecer
   * (por enquanto só blur)
   */
  validateOn?: "blur";
};
