// masks/cpf.mask.ts
import { MaskHandler } from "./mask.types";
import { applyMask, isMaskComplete } from "./mask.utils";

export const maskCPF: MaskHandler = {
  format: (raw) => applyMask(raw, "000.000.000-00"),

  validate: (value) => isMaskComplete(value, "000.000.000-00"),

  validateOn: "blur",
};
