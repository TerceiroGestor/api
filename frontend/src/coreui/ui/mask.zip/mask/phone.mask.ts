import { MaskHandler } from "./mask.types";
import { applyMask, isMaskComplete } from "./mask.utils";

const PHONE_PATTERN = "(00)00000-0000";

export const phoneMask: MaskHandler = {
  format: (raw) => applyMask(raw, PHONE_PATTERN),

  validate: (value) => isMaskComplete(value, PHONE_PATTERN),

  validateOn: "blur",
};
