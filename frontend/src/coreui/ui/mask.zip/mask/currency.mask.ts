// masks/currency.mask.ts
import { MaskHandler } from "./mask.types";

export const currencyMask: MaskHandler = {
  format: (raw) => {
    const digits = raw.replace(/\D/g, "");
    if (!digits) return "";

    const number = Number(digits) / 100;

    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(number);
  },
};
